package asd;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auction.dao.BuyerDaoImpl;
import com.auction.dao.ProductDaoImpl;
import com.auction.dao.UserDaoImpl;
import com.auction.model.User;


@WebServlet("/BidCenterX")
public class BidCenterX extends HttpServlet {

	static String s="";
	static String s1 ="";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String v  = request.getParameter("bValue");
		String pid = request.getParameter("pid");
		String fp1= request.getParameter("fp").trim();
		double fp = Double.parseDouble(fp1);
		//System.out.println(value+" "+pid);
		double value=0.0;
		ProductDaoImpl pimpl=new ProductDaoImpl();
		if(v.matches("[0-9]+"))
		{
			 value = Double.parseDouble(v);
		if(pimpl.updateProductPrice(pid, value))
		{
			HttpSession session=request.getSession();
			String uname=(String)session.getAttribute("user");
			//System.out.println(uname);
			UserDaoImpl uimpl=new UserDaoImpl();
			User u=uimpl.getUser(uname);
			BuyerDaoImpl bimpl=new BuyerDaoImpl();
			System.out.println(bimpl.insertBuyer(pid, u.getUser_id()));
			s=u.getUser_id();
			System.out.println(s+"qsmqwm");
			if(fp < value)
			{
				s1 = "Sucess";
				System.out.println("sgd");
			}
			else
			{
				s1 = "Unsuccess";
				System.out.println("hii");
			}
			//request.setAttribute("uid",u.getUser_id());
			response.sendRedirect("bid.jsp");
			
		}
		else
		{
			if(fp < value)
			{
				s1 = "Sucess";
			}
			else
			{
				s1 = "Unsuccess";
				System.out.println("shaxg");
			}
			response.sendRedirect("bid.jsp");
		}
		}
		else
		{
			s1 = "Unsuccess1";
			System.out.println("hello");
			response.sendRedirect("bid.jsp");
		}
	}
	public static String getS() {
		return s;
	}

	public static void setS(String s) {
		Welcome.s = s;
	}

	public static String getS1() {
		return s1;
	}

	public static void setS1(String s1) {
		Welcome.s1 = s1;
	}

	
	
}
