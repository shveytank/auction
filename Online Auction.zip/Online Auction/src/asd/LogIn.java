package asd;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auction.dao.BuyerDaoImpl;
import com.auction.dao.UserDaoImpl;
import com.auction.model.User;

@WebServlet("/LogIn")
public class LogIn extends HttpServlet {
	static String str = "";
	static String x="";
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String id=""; 
		
		String pass ="";
		pass= request.getParameter("pass").trim();
		id= request.getParameter("id").trim();
		boolean b=false;
		if((id.equals("") || pass.equals("")))
				{
			str="error";
			response.sendRedirect("login.jsp");
		
				}
		else
		{
			b= getUser(id, pass);
			System.out.println(b);
		if (b == true) {
			HttpSession session = request.getSession();
			session.setAttribute("user", id);
			str="";
			UserDaoImpl uimpl=new UserDaoImpl();
			User u=uimpl.getUser(id);
			x=u.getUser_id();
			response.sendRedirect("welcome.jsp");
		} else {
			str="error";
			response.sendRedirect("login.jsp");
		}
		}
	}
	

	public static boolean getUser(String id, String pass) {
		UserDaoImpl u = new UserDaoImpl();
		User us = u.getUser(id);
		String pwd="";
		if(us!=null)
		pwd = us.getPwd();
		if (pwd.equals(pass))
			return true;
		else
			return false;
	}
	public static String getX()
	{
		return str;
	}
	public static void setX(String str1)
	{
		str = str1;
	}

	public static String getStr() {
		return str;
	}

	public static void setStr(String str) {
		LogIn.str = str;
	}

}
