package asd;



public class Purchase {

		String name;

		String fp;

		String des;

		public Purchase(String name, String fp, String des) {

			super();

			this.name = name;

			this.fp = fp;

			this.des = des;

		}

		public String getName() {

			return name;

		}

		public void setName(String name) {

			this.name = name;

		}

		public String getFp() {

			return fp;

		}

		public void setFp(String fp) {

			this.fp = fp;

		}

		public String getDes() {

			return des;

		}

		public void setDes(String des) {

			this.des = des;

		}

		

}

