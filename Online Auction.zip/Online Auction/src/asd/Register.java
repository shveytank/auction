package asd;

import java.io.IOException;
import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.auction.dao.UserDaoImpl;
import com.auction.model.User;

@WebServlet("/Register")
public class Register extends HttpServlet {
	static String s = "";
	static String s1 = "";
	static String s2 = "";
	static String s3 = "";
	static String s4 = "";
	static String s5 = "";
	static String s6 = "";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("usernameX");
		String first_name=request.getParameter("first_name");
		String last_name=request.getParameter("last_name");
		String passwordX=request.getParameter("passwordX");
		String passwordY=request.getParameter("passwordY");
		String street=request.getParameter("street");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String pincode=request.getParameter("pincode");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		String paypal=request.getParameter("paypal");
		String userX = "admin";
		String user_id = String.format("%040d", new BigInteger(UUID.randomUUID().toString().replace("-", ""), 16));
		String add=street+","+city+","+state+","+pincode;
		System.out.println(name+" "+first_name+" "+last_name+" "+passwordX+
				" "+passwordY+" "+add+" "+phone+" "+email+" "+paypal);
		int i = 0;
		if (name.equals("") || phone.equals("") || email.equals("")
				|| passwordX.equals("") || passwordY.equals("")
				|| pincode.equals("") || first_name.equals("") || last_name.equals("")
				|| street.equals("") || city.equals("") || state.equals("") 
				|| paypal.equals("")) {
			s5 = "*All fields are mandatory*";
			i = 1;
		}
		else {
			if (!(passwordX.equals(passwordY)))

			{
				s = "Both password did not match.";
				// response.sendRedirect("register.jsp");
				i = 1;
			}
			if (!(pincode.matches("[0-9]{6}"))) {
				s1 = "Incorrect pincode";
				// response.sendRedirect("register.jsp");
				i = 1;
			}
			if (!(email.contains("@"))) {
				s2 = "Invalid Email";
				// response.sendRedirect("register.jsp");
				i = 1;
			}

			if (!(phone.matches("[1-9][0-9]{9}"))) {
				s3 = "Incorrect number";
				// response.sendRedirect("register.jsp");
				i = 1;
			}
			int z=0;
			UserDaoImpl uimpl=new UserDaoImpl();
			List<User> users=uimpl.getUsers();
			for(User e:users)
			{
			if (name.equals(e.getUser_name())) {
				
				// response.sendRedirect("register.jsp");
				z=1;
			}
			}
			if(z==1)
			{
				s4 = "UserName already exists";
				i = 1;
				z=0;
			}

		}
		if (i == 1) {
			response.sendRedirect("register.jsp");
			
		}
		else
		{
		User u=new User(user_id,name,first_name,last_name,passwordX,add,phone,email,paypal);
		UserDaoImpl uimpl=new UserDaoImpl();
		//System.out.println(uimpl.insertUser(u));
		if(uimpl.insertUser(u)){
		s6 = "*User registered successfully*";
		response.sendRedirect("login.jsp");
		}
		else
			response.sendRedirect("register.jsp");
		}
		i = 0;
	}
	public static String getS() {
		return s;
	}

	public static void setS(String s) {
		Register.s = s;
	}

	public static String getS1() {
		return s1;
	}

	public static void setS1(String s1) {
		Register.s1 = s1;
	}

	public static String getS2() {
		return s2;
	}

	public static void setS2(String s2) {
		Register.s2 = s2;
	}

	public static String getS3() {
		return s3;
	}
	public static String getS4() {
		return s4;
	}
	public static void setS4(String s4) {
		Register.s4 = s4;
	}
	public static String getS5() {
		return s5;
	}
	public static void setS5(String s5) {
		Register.s5 = s5;
	}
	public static String getS6() {
		return s6;
	}
	public static void setS6(String s6) {
		Register.s6 = s6;
	}
	public static void setS3(String s3) {
		Register.s3 = s3;
	}


}
