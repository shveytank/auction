package asd;



public class Sale {

	String name;

	String fp;

	String des;

	String bid;

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getFp() {

		return fp;

	}

	public void setFp(String fp) {

		this.fp = fp;

	}

	public String getDes() {

		return des;

	}

	public void setDes(String des) {

		this.des = des;

	}

	public String getBid() {

		return bid;

	}

	public void setBid(String bid) {

		this.bid = bid;

	}

	public Sale(String name, String fp, String des, String bid) {

		super();

		this.name = name;

		this.fp = fp;

		this.des = des;

		this.bid = bid;

	}

	

}