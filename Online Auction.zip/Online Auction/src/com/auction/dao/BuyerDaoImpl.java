package com.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import asd.Purchase;

import com.auction.model.Buyer;
import com.auction.model.Product;
import com.auction.model.PurchaseInfo;
import com.auction.model.User;
import com.auction.util.BuyerDao;
import com.auction.util.DBConstants;
import com.auction.util.DbUtil;

public class BuyerDaoImpl implements BuyerDao {
	Connection con = null;

	@Override
	public List<Purchase> buyerList(String buyer_id) {

		List<Purchase> purchasesList=new ArrayList<>();
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("select name,sold_price,descrip from product where pid in(select product_id from buyer where buyer_id=?)");
			pst.setString(1, buyer_id);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String s2=rs.getDouble(2)+"";
				purchasesList.add(new Purchase(rs.getString(1),s2,rs.getString(3)));

			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return purchasesList;
	}

	@Override
	public String insertBuyer(String pid, String uid) {
		String msg=null;
        try
        {
                        con=DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
                       PreparedStatement pst1=con.prepareStatement("delete from buyer where product_id=?");
                  
                       pst1.setString(1, pid);
                        int r1=pst1.executeUpdate();
                       
                        PreparedStatement pst=con.prepareStatement("insert into Buyer values(?,?)");
                        pst.setString(1, uid);
                        pst.setString(2, pid);
                        int r=pst.executeUpdate();
                        if(r>0)
                                        msg="Buyer Successfully added";
                        else
                                        msg="Buyer not added";
                       
                        con.close();
                        
        }
        catch(Exception e)
        {
                        e.printStackTrace();
        }
        return msg;
	}

}
