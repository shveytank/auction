package com.auction.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import com.auction.model.Product;
import com.auction.model.User;
import com.auction.util.DBConstants;
import com.auction.util.DbUtil;
import com.auction.util.ProductDao;

public class ProductDaoImpl implements ProductDao {

	Connection con = null;

	/*
	 * public String userId(User u) { String s=u.getUser_id(); return s; }
	 */
	@Override
	public String insertProduct(Product p) {
		String msg = null;
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("insert into product values(?,?,?,?,?,?,?,?,?)");
			pst.setString(1, p.getPid());
			pst.setString(2, p.getName());
			pst.setString(3, p.getShortdesc());
			pst.setString(4, p.getDesc());
			pst.setString(5, p.getCategory());
			pst.setDouble(6, p.getStart_price());
			java.util.Date mydate = p.getBid_end_date();
			// pst.setDate(7,(Date) p.getBid_end_date());
			java.sql.Date sqldate = new java.sql.Date(mydate.getTime());
			pst.setDate(7, sqldate);

			pst.setDouble(8, p.getFinal_price());

			java.util.Date mydate1 = p.getStart_date();
			// pst.setDate(9,(Date) p.getStart_date());
			java.sql.Date sqldate1 = new java.sql.Date(mydate1.getTime());
			pst.setDate(9, sqldate1);

			int r = pst.executeUpdate();
			if (r > 0) {
				msg = "Product Successfully added";
				/*
				 * SellerDaoImpl simpl=new SellerDaoImpl(); UserDaoImpl
				 * uimpl=new UserDaoImpl(); simpl.insertSeller(p, uimpl.);
				 */
			} else
				msg = "Product not added";

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public Product getProduct(String pid) {
		Product p = null;
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("select * from product where pid=?");
			pst.setString(1, pid);
			ResultSet rs = pst.executeQuery();
			rs.next();
			p = new Product(rs.getString(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getDouble(6),
					rs.getDate(7), rs.getDouble(8), rs.getDate(9));
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}

	@Override
	public List<Product> getProducts() {
		List<Product> products = new ArrayList<>();
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from product");
			while (rs.next()) {
				products.add(new Product(rs.getString(1), rs.getString(2), rs
						.getString(3), rs.getString(4), rs.getString(5), rs
						.getDouble(6), rs.getDate(7), rs.getDouble(8), rs
						.getDate(9)));

			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return products;
	}

	@Override
	public String deleteProduct(String pname) {
		// TODO Auto-generated method stub
		String msg = null;
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("delete from product where name=?");
			pst.setString(1, pname);
			int rs = pst.executeUpdate();
			if (rs > 0)
				msg = "Product Successfully deleted";
			else
				msg = "Product not deleted";
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return msg;
	}

	@Override
	public List<Product> search(String category) {
		// TODO Auto-generated method stub
		List<Product> products = new ArrayList<>();
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);

			PreparedStatement pst = con
					.prepareStatement("select * from product where category=?");
			pst.setString(1, category);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				products.add(new Product(rs.getString(1), rs.getString(2), rs
						.getString(3), rs.getString(4), rs.getString(5), rs
						.getDouble(6), rs.getDate(7), rs.getDouble(8), rs
						.getDate(9)));

			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return products;

	}

	public boolean updateProductPrice(String pid, Double bvalue) {
		boolean msg = false;
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("update  product set sold_price=? where pid=? and sold_price<?");
			pst.setDouble(1, bvalue);
			pst.setString(2, pid);
			pst.setDouble(3, bvalue);
			int rs = pst.executeUpdate();
			if (rs > 0)
				msg = true;
			else
				msg = false;
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return msg;
	}

	public String getRecentBid(String pid) {
		String price = "";

		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("select sold_price from product where pid=?");
			pst.setString(1, pid);
			ResultSet rs = pst.executeQuery();
			rs.next();
			// p=new Product(rs.getString(1), rs.getString(2), rs.getString(3),
			// rs.getString(4),rs.getString(5),rs.getDouble(6),rs.getDate(7),rs.getDouble(8),rs.getDate(9));
			price = String.valueOf(rs.getDouble(1));
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}

}
