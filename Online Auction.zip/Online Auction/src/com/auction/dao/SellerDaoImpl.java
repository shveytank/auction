package com.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import asd.Sale;

import com.auction.model.Product;
import com.auction.model.SalesInfo;
import com.auction.model.Seller;
import com.auction.model.User;
import com.auction.util.DBConstants;
import com.auction.util.DbUtil;
import com.auction.util.SellerDao;

public class SellerDaoImpl implements SellerDao {
	Connection con=null;
	@Override
		public List<Sale> sellerList(String seller_id) {
			
		 List<Sale> salesInfoList=new ArrayList<>();
		        try
		        {
		                        con=DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
		                        PreparedStatement pst=con.prepareStatement("select p.name,p.sold_price,p.descrip,u.user_name from product p,buyer b,seller s,user u  where s.product_id=p.pid and p.pid=b.product_id and b.buyer_id=u.user_id and s.seller_id=?");
	                            pst.setString(1, seller_id);
	                            ResultSet rs=pst.executeQuery();
		                        while(rs.next())
		                        {
		                        	String s1=rs.getDouble(2)+"";
		                        	salesInfoList.add(new Sale(rs.getString(1),s1,rs.getString(3),rs.getString(4)));
		                                        
		                        }
		                        con.close();
		        }
		        catch(Exception e)
		        {
		                        e.printStackTrace();
		        }
		        return salesInfoList;
       
}
	
		
	@Override
	public String insertSeller(String pid, String uid) {
		// TODO Auto-generated method stub
		
		String msg=null;
        try
        {
                        con=DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
                        PreparedStatement pst=con.prepareStatement("insert into seller values(?,?)");
                        pst.setString(1, uid);
                        pst.setString(2, pid);
                        int r=pst.executeUpdate();
                        if(r>0)
                                        msg="Seller Successfully added";
                        else
                                        msg="Seller not added";
                        
                        con.close();
        }
        catch(Exception e)
        {
                        e.printStackTrace();
        }
        return msg;
	}

	/*public List<SalesInfo> getMySales()
	{
		 List<SalesInfo> mysales=new ArrayList<>();
         try
         {
                         con=DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
                         ProductDaoImpl pimpl=new ProductDaoImpl();
                         BuyerDaoImpl bimpl=new BuyerDaoImpl();
                         SellerDaoImpl simpl=new SellerDaoImpl();
                         
                         PreparedStatement pst=con.prepareStatement("select p.name,p.sold_price,p.descrip,b.buyer_id from product p,buyer b,seller s where s.product_id=p.pid and p.pid=b.product_id and s.seller_id=?");
                         pst.setString(1, uid);
                         int rs=pst.executeUpdate();
                         while(rs.next())
                         {
                                         mysales.add(new Product(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getDouble(6),rs.getDate(7),rs.getDouble(8),rs.getDate(9)));
                                         
                         }
                         con.close();
         }
         catch(Exception e)
         {
                         e.printStackTrace();
         }
         return mysales;

	
*/
}
