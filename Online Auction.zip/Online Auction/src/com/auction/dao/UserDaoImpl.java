package com.auction.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import com.auction.model.Product;
import com.auction.model.User;
import com.auction.util.DBConstants;
import com.auction.util.DbUtil;
import com.auction.util.UserDao;

public class UserDaoImpl implements UserDao {

	Connection con = null;

	@Override
	public boolean insertUser(User u) {
		//String msg = null;
		boolean msg=false;
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?)");
			pst.setString(1, u.getUser_id());
			pst.setString(2, u.getUser_name());
			pst.setString(3, u.getFirst_name());
			pst.setString(4, u.getLast_name());
			pst.setString(5, u.getPwd());
			pst.setString(6, u.getAddress());
			pst.setString(7, u.getMobile_no());

			pst.setString(8, u.getEmail());
			pst.setString(9, u.getPaypal_id());

			int r = pst.executeUpdate();
			if (r > 0)
			{
				msg =true;
			/*	ProductDaoImpl pimpl=new ProductDaoImpl();
				String id=pimpl.userId(u);*/
			}
			else
				msg = false;

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public User getUser(String uname) {
		User u = null;
		try {
			con = DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,
					DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst = con
					.prepareStatement("select * from user where user_name=?");
			pst.setString(1, uname);
			ResultSet rs = pst.executeQuery();
			rs.next();
			u = new User(rs.getString(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6),
					rs.getString(7), rs.getString(8), rs.getString(9));
			//System.out.println(u);
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return u;
	}
    public List<User> getUsers() {
        List<User> users=new ArrayList<>();
        try
        {
                        con=DbUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
                        Statement st=con.createStatement();
                        ResultSet rs=st.executeQuery("select * from user");
                        while(rs.next())
                        {
                                        users.add(new User(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6),rs.getString(7), rs.getString(8),rs.getString(9)));
                                        
                        }
                        con.close();
        }
        catch(Exception e)
        {
                        e.printStackTrace();
        }
        return users;
}
	

}