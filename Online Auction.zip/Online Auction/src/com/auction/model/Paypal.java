package com.auction.model;

public class Paypal 
{
  String paypal_id;
  String pwd;
public String getPaypal_id() {
	return paypal_id;
}
public void setPaypal_id(String paypal_id) {
	this.paypal_id = paypal_id;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public Paypal(String paypal_id, String pwd) {
	super();
	this.paypal_id = paypal_id;
	this.pwd = pwd;
}
public Paypal() {
	super();
	// TODO Auto-generated constructor stub
}
  
}
