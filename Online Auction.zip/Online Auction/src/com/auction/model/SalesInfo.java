package com.auction.model;

public class SalesInfo {

	private String productName;
	private double finalPrice;
	private String desc;
	private String buyerId;
	public SalesInfo(String productName, double finalPrice, String desc,
			String buyerId) {
		super();
		this.productName = productName;
		this.finalPrice = finalPrice;
		this.desc = desc;
		this.buyerId = buyerId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	
}
