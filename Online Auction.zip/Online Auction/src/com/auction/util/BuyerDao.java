package com.auction.util;

import java.util.List;

import asd.Purchase;

import com.auction.model.Buyer;
import com.auction.model.Product;
import com.auction.model.PurchaseInfo;
import com.auction.model.User;

public interface BuyerDao {
	List<Purchase> buyerList(String buyer_id);
	String insertBuyer(String pid,String uid);
}
