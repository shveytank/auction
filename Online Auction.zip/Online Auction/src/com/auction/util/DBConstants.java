package com.auction.util;

import java.util.Properties;

public class DBConstants {
      //Properties p=DbUtil.getProperties("dbProps.properties");
      public static final String DRIVER="com.mysql.jdbc.Driver";
      public static final String URL="jdbc:mysql://localhost/e_auction";
      public static final String UNAME="root";
      public static final String PWD="root";
      
      

}
